<section id="statistics" class="content-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center latest-job margin-bottom-20">
        <h1>Our Statistics</h1>
      </div>
    </div>
    <div class="row">
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
         <?php
                  $sql = "SELECT * FROM job_post";
                  $result = $conn->query($sql);
                  if($result->num_rows > 0) {
                    $totalno = $result->num_rows;
                  } else {
                    $totalno = 0;
                  }
                ?>
          <h3><?php echo $totalno; ?></h3>
          <p>Job Offers</p>
        </div>
        <div class="icon">
          <i class="ion ion-ios-paper"></i>
        </div>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
              <?php
                  $sql = "SELECT * FROM company WHERE active='1'";
                  $result = $conn->query($sql);
                  if($result->num_rows > 0) {
                    $totalno = $result->num_rows;
                  } else {
                    $totalno = 0;
                  }
                ?>
          <h3><?php echo $totalno; ?></h3>
          <p>Registered Company</p>
        </div>
        <div class="icon">
            <i class="ion ion-briefcase"></i>
        </div>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
         <?php
                  $sql = "SELECT * FROM users WHERE resume!=''";
                  $result = $conn->query($sql);
                  if($result->num_rows > 0) {
                    $totalno = $result->num_rows;
                  } else {
                    $totalno = 0;
                  }
                ?>
          <h3><?php echo $totalno; ?></h3>
          <p>CV'S/Resume</p>
        </div>
        <div class="icon">
          <i class="ion ion-ios-list"></i>
        </div>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
           <?php
                  $sql = "SELECT * FROM users WHERE active='1'";
                  $result = $conn->query($sql);
                  if($result->num_rows > 0) {
                    $totalno = $result->num_rows;
                  } else {
                    $totalno = 0;
                  }
                ?>
          <h3><?php echo $totalno; ?></h3>
          <p>Daily Users</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-stalker"></i>
        </div>
      </div>
    </div>
    <!-- ./col -->
  </div>
  </div>
</section>