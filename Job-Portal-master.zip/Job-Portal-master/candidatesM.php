<section id="candidates" class="content-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center latest-job margin-bottom-20">
        <h1>Candidates</h1>
        <p>Finding a job just got easier. Create a profile and apply with single mouse click.</p>            
      </div>
    </div>
    <div class="row">
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail candidate-img">
          <img src="img/browse.jpg" alt="Browse Jobs">
          <div class="caption">
            <h3 class="text-center">Browse Jobs</h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail candidate-img">
          <img src="img/interviewed.jpeg" alt="Apply & Get Interviewed">
          <div class="caption">
            <h3 class="text-center">Apply & Get Interviewed</h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail candidate-img">
          <img src="img/career.jpg" alt="Start A Career">
          <div class="caption">
            <h3 class="text-center">Start A Career</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>