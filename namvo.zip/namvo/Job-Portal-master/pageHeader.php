<section class="content-header bg-main">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center index-head">
        <h1>All <strong>JOBS</strong> In One Place</h1>
        <p>One search, global reach</p>
        <p class="mainButton"><a class="btn btn-success btn-lg" href="jobs.php" role="button">Search Jobs</a></p>
        <p class="mainButton"><a class="btn btn-success btn-lg" href="candidates.php" role="button">Search Candidates</a></p>
      </div>
    </div>
  </div>
</section>