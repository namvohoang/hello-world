<?php

session_start();

require_once("db.php");

$limit = 4;

if(isset($_GET["page"])) {
	$page = $_GET['page'];
} else {
	$page = 1;
}

$start_from = ($page-1) * $limit;

$sql = "SELECT * FROM users LIMIT $start_from, $limit";
$result = $conn->query($sql);
if($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
             ?>
		   <div class="attachment-block clearfix">
          <div class="attachment-pushed" style="margin-left: 10px;">
            <h4 class="attachment-heading">
              <?php echo $row['firstname'] . " " . $row['lastname']; ?>
              <span class="attachment-heading pull-right">
                Resume <?php echo $row['resume']; ?>
              </span>
            </h4>
            <div class="attachment-text">
                <div>
                  <strong>
                    <?php 
                      if($row['skills']) {
                        echo $row['skills'];
                      }
                      else {
                        echo "All Jobs";
                      } 
                    ?>                       
                  </strong>
                </div>
            </div>
            <div class="attachment-text">
                <div>
                  <strong>
                    <?php echo "Tel: " . $row['contactno']; ?>                       
                  </strong>
                </div>
            </div>
          </div>
        </div>
		<?php
			}
}

$conn->close();