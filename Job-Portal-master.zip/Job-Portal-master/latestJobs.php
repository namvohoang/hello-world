<section class="content-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12 latest-job margin-bottom-20">
        <h1 class="text-center">Latest Jobs</h1>
      </div>
    </div>    
    <div class="row">
        <?php 
      /* Show any 4 random job post
       * 
       * Store sql query result in $result variable and loop through it if we have any rows
       * returned from database. $result->num_rows will return total number of rows returned from database.
      */
      $sql = "SELECT * FROM job_post Order By Rand() Limit 4";
      $result = $conn->query($sql);
      if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) 
        {
          $sql1 = "SELECT * FROM company WHERE id_company='$row[id_company]'";
          $result1 = $conn->query($sql1);
          if($result1->num_rows > 0) {
            while($row1 = $result1->fetch_assoc()) 
            {
         ?>
        
        <a href="view-job-post.php?id=<?php echo $row['id_jobpost']; ?>">
                
              
          <div class="col-sm-3 col-md-3">
            <div class="thumbnail candidate-img">
              <img src="img/browse.jpg" alt="Browse Jobs">
              <div class="caption">
                <h5 class="text-center">
                  <?php echo $row['jobtitle']; ?>
                </h5>
              </div>
              <div class="caption">
                <h4 class="text-center">
                  $<?php echo $row['maximumsalary']; ?>/Month
                </h4>
              </div>
            </div>
          </div>
          </a>

        
      <?php
          }
        }
        }
      }
      ?>
      </div>
  </div>
</section>