<section id="about" class="content-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center latest-job margin-bottom-20">
        <h1>About US</h1>                      
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <img src="img/browse.jpg" class="img-responsive">
      </div>
      <div class="col-md-6 about-text margin-bottom-20">
        <p>
          Lorem ipsum dolor sit amet, consectetur adipisicing.
        </p>
        <p> 
          The online job portal application allows job seekers and recruiters to connect.
          The application provides the ability for job seekers to create their accounts, 
          upload their profile and resume, search for jobs, apply for jobs, view different job openings. 
          The application provides the ability for companies to create their accounts, 
          search candidates, create job postings, and view candidates applications.
        </p>
        <p>
          This website is used to provide a platform for potential candidates 
          to get their dream job and excel in yheir career.
          This site can be used as a paving path for both companies and job-seekers for a better life .
        </p>
      </div>
    </div>
  </div>
</section>