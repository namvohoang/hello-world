<section id="company" class="content-header">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center latest-job margin-bottom-20">
        <h1>Companies</h1>
        <p>Hiring? Register your company for free, browse our talented pool, post and track job applications</p>            
      </div>
    </div>
    <div class="row">
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail company-img">
          <img src="img/postjob.png" alt="Browse Jobs">
          <div class="caption">
            <h3 class="text-center">Post A Job</h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail company-img">
          <img src="img/manage.jpg" alt="Apply & Get Interviewed">
          <div class="caption">
            <h3 class="text-center">Manage & Track</h3>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-md-4">
        <div class="thumbnail company-img">
          <img src="img/hire.png" alt="Start A Career">
          <div class="caption">
            <h3 class="text-center">Hire</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>