<footer class="main-footer" style="margin-left: 0px;">
  <div class="text-center">
    <strong>Copyright &copy; 2016-2017 <a href="learningfromscratch.online">Job Portal</a>.</strong> All rights
  reserved.
  </div>
</footer>